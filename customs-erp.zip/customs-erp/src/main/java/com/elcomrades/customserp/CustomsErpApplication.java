package com.elcomrades.customserp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomsErpApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomsErpApplication.class, args);
	}

}
