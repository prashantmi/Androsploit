package com.elcomrades.customserp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomsErpApplicationTests {

	@Test
	void contextLoads() {
	}

}
